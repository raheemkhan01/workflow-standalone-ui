export default function Loading () {
    return (
        <main>
            <h2 className="text-blue-500 leading-8 text-2xl text-center my-7">Loading ...</h2>
        </main>
    )
}