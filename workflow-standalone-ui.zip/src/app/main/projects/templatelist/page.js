import Templates from '@/Components/Templates/Templates'
import React from 'react'




const pages = () => {
  return (
    <div>
      <Templates/>
    </div>
  )
}

export default pages
