const array = [
    {
        id: 1,
        name: {
            image: { src: 'https://cdn.pixabay.com/photo/2017/06/26/02/47/man-2442565_1280.jpg' },
            name: "Lori Bryson"
        },
        Designation: "UX Designer",
        MailID: "Demo@mail.com"
    },
    {
        id: 2,
        name: {
            image: { src: 'https://cdn.pixabay.com/photo/2015/07/20/12/53/gehlert-852762_1280.jpg' },
            name: "Lori Bryson"
        },
        Designation: "UX Designer",
        MailID: "Demo@mail.com"
    },
    {
        id: 3,
        name: {
            image: { src: 'https://cdn.pixabay.com/photo/2015/08/05/04/02/people-875597_1280.jpg' },
            name: "Lori Bryson"
        },
        Designation: "UX Designer",
        MailID: "Demo@mail.com"
    },
    {
        id: 4,
        name: {
            image: { src: 'https://cdn.pixabay.com/photo/2017/09/25/13/12/man-2785071_1280.jpg' },
            name: "Lori Bryson"
        },
        Designation: "UX Designer",
        MailID: "Demo@mail.com"
    },
    {
        id: 5,
        name: {
            image: { src: 'https://cdn.pixabay.com/photo/2015/08/05/04/25/people-875617_1280.jpg' },
            name: "Lori Bryson"
        },
        Designation: "UX Designer",
        MailID: "Demo@mail.com"
    },
]
export default array;