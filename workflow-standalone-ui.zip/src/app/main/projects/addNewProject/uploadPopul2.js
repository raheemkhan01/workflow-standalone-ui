// import React from 'react'
// import ReactDOM from "react-dom";
// import { Dropzone, FileMosaic } from "@dropzone-ui/react";

// function UploadPopul2() {
//     const [files, setFiles] = React.useState([]);
//     const updateFiles = (incommingFiles) => {
//       setFiles(incommingFiles);
//     };
//     return (
//       <Dropzone onChange={updateFiles} value={files}>
//         {files.map((file) => (
//           <FileMosaic {...file} preview />
//         ))}
//       </Dropzone>
//     );
//   }
  
//   ReactDOM.render(<UploadPopul2 />, document.querySelector("#app"));
  

