import React from 'react'
import DisplayUsers from '@/Components/AddResources/DisplayUsers'

const showResources = () => {
  return (
      <div><DisplayUsers/></div>
  )
}

export default showResources