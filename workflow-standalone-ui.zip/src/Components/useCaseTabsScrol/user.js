import React from "react";

const user = () => {
  return (
    <div>
      <div className=" border w-10">
        
          <h1>API Developer</h1>
        
      </div>
    </div>
  );
};

export default user;
