export const resourcePoolData = [
  "Project Manager",
  "UX Researcher",
  "UI Designer",
  "UI Developer",
  "API Developer",
  "Tester",
  "CI/CD",
];